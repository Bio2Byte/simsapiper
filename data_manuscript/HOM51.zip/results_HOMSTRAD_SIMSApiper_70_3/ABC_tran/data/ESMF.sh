#!/bin/bash

#SBATCH --partition=ampere_gpu
#SBATCH --time=00:20:00
#SBATCH --nodes=1
#SBATCH --gpus-per-node=1
#SBATCH --ntasks-per-gpu=1
#SBATCH --cpus-per-gpu=8

export TORCH_HOME=$VSC_SCRATCH/ESMFold

module load ESM-2/2.0.0-foss-2021a-CUDA-11.3.1
module load OpenFold/1.0.1-foss-2021a-CUDA-11.3.1
module load PyTorch-Lightning/1.5.9-foss-2021a-CUDA-11.3.1

SEQUENCES=./results/seqs/structureless_seqs.fasta
FOLDER_STRUCTURES=./data/structures

python3 $VSC_SCRATCH/ESMFold/esmfold_inference.py --chunk-size 32 -i $SEQUENCES -o $FOLDER_STRUCTURES
