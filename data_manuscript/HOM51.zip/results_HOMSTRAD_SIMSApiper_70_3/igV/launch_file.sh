#!/bin/bash
module load Nextflow/23.04.2
data=/scratch/brussel/vo/000/bvo00023/vsc10611/HOMSTRAD_subDS_4_25/igV
now=`date +"%Y_%m_%d_%H_%M_%S"`
output_name=${now}
output_folder=$data/results/$output_name
mkdir -p $data/results
mkdir -p $output_folder
nextflow run /scratch/brussel/vo/000/bvo00023/vsc10611/simsapiper/simsapiper.nf \
    -profile hydra \
    --data $data/data \
    --seqQC 5 \
    --model true \
    --strucQC 1 \
    --dssp true \
    --squeeze "E" \
    --squeezePerc 70 \
    --reorder true \
    --outFolder $output_folder \
    |& tee  $output_folder/run_report_$output_name.nflog
sessionName=$(sed -n '2s/.*\[\(.*\)\].*/\1/p' $output_folder/run_report_$output_name.nflog)
nextflow log | grep $sessionName >> $output_folder/run_report_$output_name.nflog
