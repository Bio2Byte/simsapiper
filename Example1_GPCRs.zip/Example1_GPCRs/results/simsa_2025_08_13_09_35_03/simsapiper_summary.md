# Summary file for SIMSApiper 
Find detailed explations for each step on [GitHub](https://github.com/Bio2Byte/simsapiper) 

All output files can be found here:  /rhea/scratch/brussel/vo/000/bvo00023/vsc10611/GPCRs_minimagic_2/results/simsa_2025_08_13_09_35_03

The command executed was:  nextflow run /scratch/brussel/vo/000/bvo00023/vsc10611/simsapiper/simsapiper.nf -profile hydra --data /scratch/brussel/vo/000/bvo00023/vsc10611/GPCRs_minimagic_2/data --minimagic
# Input sequences files 
* No. of sequences in inputfile(s):  30
* Input files can be found in  /scratch/brussel/vo/000/bvo00023/vsc10611/GPCRs_minimagic_2/data/seqs
* SIMSApiper found these files:  GPCRs_subset.fasta
# 1 Data preparation
## 1.2 Data reduction with CD-Hit
* Similarity cutoff for CD-Hit:  false
## 1.3 Invalid sequences 
* Sequences removed because they contained more then 10 % non-standard or unresolved amino acids:  0
# 2 Structural information
## 2.1 Identify missing models
* Models found in /scratch/brussel/vo/000/bvo00023/vsc10611/GPCRs_minimagic_2/data/structures
* Models found at start of the pipeline:  0
## 2.2 Search AFDB:  true
* Models found in AlphaFold Database:  29
## 2.4 Use ESM Atlas:  true
* Models generated with ESMAtlas:  1
## 2.4 Alternative: Use local ESMfold:  false
## 2.6 No. of sequences not matched to a model:  0
# 3 Generation of subsets
## 3.1 Subsets were generated from input files: true
## 3.2 Automatically generated subsets : false 
# 4 Align each subsets with T-Coffee
* Cleaned, matched sequences to submit to T-coffee: 
    *  /rhea/scratch/brussel/vo/000/bvo00023/vsc10611/GPCRs_minimagic_2/results/simsa_2025_08_13_09_35_03/seqs/for_t-coffee/converted_GPCRs_subset_matchedModel.fasta
* Additional T-Coffee parameters:  false
# 5 Align subset alignments with MAFFT
* Alignment of subset alignments, structureless and orphan sequences  /rhea/scratch/brussel/vo/000/bvo00023/vsc10611/GPCRs_minimagic_2/results/simsa_2025_08_13_09_35_03/msas/merged_minimagicMSA.fasta
* Additional MAFFT parameters:  false
# 6 Run DSSP: true
* DSSP file can be found in /scratch/brussel/vo/000/bvo00023/vsc10611/GPCRs_minimagic_2/data/dssp
# 7 Improve MSA 
## 7.1 Map DSSP to MSA
* DSSP codes mapped to merged alignment: /rhea/scratch/brussel/vo/000/bvo00023/vsc10611/GPCRs_minimagic_2/results/simsa_2025_08_13_09_35_03/msas/dssp_merged_minimagicMSA.fasta
[('E1', (44, 47)), ('H1', (54, 84)), ('H2', (102, 130)), ('E2', (141, 143)), ('H3', (144, 177)), ('H4', (183, 186)), ('H5', (198, 223)), ('E3', (233, 234)), ('H6', (241, 245)), ('H7', (253, 287)), ('H8', (325, 330)), ('H9', (334, 346)), ('H10', (348, 358)), ('H11', (382, 393)), ('H12', (395, 407)), ('H13', (409, 423))]
## 7.2 Squeeze MSA towards conserved secondary structure elements
* Categories selected for squeezing:  H,E
* Threshold for region to be considered conserved:  60
* Squeezed alignment:  /rhea/scratch/brussel/vo/000/bvo00023/vsc10611/GPCRs_minimagic_2/results/simsa_2025_08_13_09_35_03/msas/squeezed_merged_minimagicMSA.fasta
## 7.3 Map DSSP to squeezed MSA
* DSSP codes mapped to merged alignment: /rhea/scratch/brussel/vo/000/bvo00023/vsc10611/GPCRs_minimagic_2/results/simsa_2025_08_13_09_35_03/msas/dssp_squeezed_merged_minimagicMSA.fasta
## Gap reduction
* The inital merged alignment has  5775  gaps.
* The the squeezed alignment has  5535  gaps.
* The squeezing step removed  240  gaps from the alignment.
## Estimated sequence identity
* The final alignment contains 1 conserved positions and 229 gapless positions of 521 total positions.
* The average pairwise sequence identity in the final alignment is 22.83%. Gaps were treated as mismatches.
# 8 Reorder MSA 
* Alignment reorded by:  true
* Reordered alignment:  /rhea/scratch/brussel/vo/000/bvo00023/vsc10611/GPCRs_minimagic_2/results/simsa_2025_08_13_09_35_03/msas/reordered_squeezed_merged_minimagicMSA.fasta
# Final MSA file
/rhea/scratch/brussel/vo/000/bvo00023/vsc10611/GPCRs_minimagic_2/results/simsa_2025_08_13_09_35_03/minimagicMSA_simsa.fasta

# Execution time
* Total runtime (without queue time): 10 minutes
* Total runtime runTcoffee only: 7 minutes
